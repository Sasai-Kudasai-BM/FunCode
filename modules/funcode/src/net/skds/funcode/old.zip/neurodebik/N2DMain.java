package net.skds.funcode.neurodebik;

import net.skds.funcode.Pong;

public class N2DMain {


	public static void main(String[] args) {

		Pong pong = new Pong();

		Pong.createFrame(pong);
	}


}
