package net.skds.funcode.neurodebik.ai;

public interface NNValidator {

	float validate(SimpleNet net);
}
